# Qwen Code Preferences

- Do not verify code with Python automatically. I will provide feedback instead.